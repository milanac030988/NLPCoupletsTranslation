from fake_chatgpt_api import FakeChatGPTAPI

fake = FakeChatGPTAPI()
resp = fake.send_request("test")
print(resp)